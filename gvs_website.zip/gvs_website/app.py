from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import json, os
from datetime import date

app = Flask(__name__)
app.secret_key = "gvs_secret_key_2024"

DATA_FILE = "data.json"

def load_data():
    if not os.path.exists(DATA_FILE):
        return {"users": {"admin": {"password": "admin123", "role": "admin", "name": "Admin"}}, "attendance": {}}
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ── Public pages ──────────────────────────────────────────
@app.route("/")
def home():
    return render_template("home.html", user=session.get("user"))

@app.route("/about")
def about():
    return render_template("about.html", user=session.get("user"))

@app.route("/contact")
def contact():
    return render_template("contact.html", user=session.get("user"))

@app.route("/courses")
def courses():
    return render_template("courses.html", user=session.get("user"))

# ── Auth ──────────────────────────────────────────────────
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        data = load_data()
        user = data["users"].get(username)
        if user and user["password"] == password:
            session["user"] = {"username": username, "role": user["role"], "name": user.get("name", username)}
            return redirect(url_for("home"))
        return render_template("login.html", error="Invalid username or password", user=None)
    return render_template("login.html", user=session.get("user"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

# ── Register (admin only creates students) ────────────────
@app.route("/register", methods=["GET", "POST"])
def register():
    if not session.get("user") or session["user"]["role"] != "admin":
        return redirect(url_for("home"))
    data = load_data()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        name = request.form.get("name", "").strip()
        if username in data["users"]:
            return render_template("register.html", user=session.get("user"), error="Username already exists", users=data["users"])
        data["users"][username] = {"password": password, "role": "student", "name": name}
        save_data(data)
        return render_template("register.html", user=session.get("user"), success="Student added!", users=data["users"])
    return render_template("register.html", user=session.get("user"), users=data["users"])

# ── Attendance ────────────────────────────────────────────
@app.route("/attendance", methods=["GET", "POST"])
def attendance():
    if not session.get("user"):
        return redirect(url_for("login"))
    data = load_data()
    today = str(date.today())
    user = session["user"]

    if request.method == "POST":
        if user["role"] == "student":
            mark_date = request.form.get("date")
            if mark_date != today:
                return jsonify({"error": "Sirf aaj ki attendance mark ho sakti hai!"}), 400
            username = user["username"]
            if username not in data["attendance"]:
                data["attendance"][username] = {}
            data["attendance"][username][today] = "P"
            save_data(data)
            return jsonify({"success": True, "date": today, "status": "P"})

        elif user["role"] == "admin":
            target_user = request.form.get("target_user")
            mark_date = request.form.get("date", today)
            status = request.form.get("status", "P")
            if target_user not in data["attendance"]:
                data["attendance"][target_user] = {}
            data["attendance"][target_user][mark_date] = status
            save_data(data)
            return jsonify({"success": True})

    # GET
    if user["role"] == "student":
        username = user["username"]
        history = data["attendance"].get(username, {})
        already_marked = today in history
        return render_template("attendance.html", user=user, history=history, today=today, already_marked=already_marked)

    elif user["role"] == "admin":
        students = {k: v for k, v in data["users"].items() if v["role"] == "student"}
        all_att = data["attendance"]
        return render_template("attendance_admin.html", user=user, students=students, all_att=all_att, today=today)

    return redirect(url_for("home"))

# ── Admin dashboard ───────────────────────────────────────
@app.route("/dashboard")
def dashboard():
    if not session.get("user") or session["user"]["role"] != "admin":
        return redirect(url_for("home"))
    data = load_data()
    students = {k: v for k, v in data["users"].items() if v["role"] == "student"}
    return render_template("dashboard.html", user=session.get("user"), students=students)

if __name__ == "__main__":
    app.run(debug=True)
