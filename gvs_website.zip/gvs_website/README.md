# GVS Website

## Files Structure
```
gvs_website/
├── app.py              ← Main Flask backend
├── requirements.txt    ← Python dependencies
├── render.yaml         ← Render deployment config
├── data.json           ← Auto-created (user data & attendance)
└── templates/
    ├── base.html       ← Layout + navbar
    ├── home.html
    ├── about.html
    ├── contact.html
    ├── courses.html
    ├── login.html
    ├── register.html   ← Admin only
    ├── attendance.html ← Student view
    ├── attendance_admin.html ← Admin view
    └── dashboard.html
```

## Default Login
- **Admin**: username=`admin` password=`admin123`

## Deploy on Render (Mobile se bhi ho sakta hai)

1. GitHub pe jaao → New Repository banao (naam: gvs-website)
2. Ye saare files upload karo (templates folder ke saath)
3. render.com pe account banao (GitHub se login karo)
4. "New Web Service" click karo
5. Apna repo select karo
6. Sab settings automatic set ho jaayegi (render.yaml se)
7. "Deploy" karo — 2-3 min mein website live!

## Features
- Public: Home, About, Courses, Contact (bina login ke)
- Student login ke baad: Attendance (sirf aaj ki mark ho sakti hai)
- Admin login ke baad: Dashboard, Add Student, All Attendance
- Attendance history save hoti hai permanently
- P = Present, A = Absent
